package com.example.musicviz

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        fun btn(t: String, a: () -> Unit) = l.addView(Button(this).apply { text = t; setOnClickListener { a() } })
        btn("1. Разрешить запись звука и уведомления") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("2. Доступ к уведомлениям (названия треков)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        btn("3. Отключить оптимизацию батареи") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        btn("4. Запустить визуализацию") {
            startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 7)
        }
        btn("Остановить") { stopService(Intent(this, VisualizerService::class.java)) }
        l.addView(TextView(this).apply {
            text = "Затем: долгое нажатие на рабочем столе → Виджеты → Music Visualizer."
            setPadding(0, 32, 0, 0)
        })
        setContentView(l)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, code: Int, d: Intent?) {
        if (r == 7 && code == RESULT_OK && d != null)
            startForegroundService(Intent(this, VisualizerService::class.java).putExtra("code", code).putExtra("data", d))
    }
}
