package com.example.musicviz

import android.app.*
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.IBinder
import android.widget.RemoteViews
import kotlin.concurrent.thread
import kotlin.math.*

class VisualizerService : Service() {
    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    @Volatile private var running = false

    companion object { const val N = 1024; const val BARS = 24; const val W = 720; const val H = 300 }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("viz", "Visualizer", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "viz").setContentTitle("Визуализатор работает")
            .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        @Suppress("DEPRECATION") val data = i?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        projection = getSystemService(MediaProjectionManager::class.java)
            .getMediaProjection(i.getIntExtra("code", 0), data)
        projection!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, null)

        val cfg = AudioPlaybackCaptureConfiguration.Builder(projection!!)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA).addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build()
        val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(44100).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
        record = AudioRecord.Builder().setAudioFormat(fmt).setBufferSizeInBytes(N * 8)
            .setAudioPlaybackCaptureConfig(cfg).build()
        running = true
        thread { loop() }
        return START_NOT_STICKY // токен MediaProjection нельзя восстановить после убийства процесса
    }

    private fun loop() {
        val rec = record ?: return
        val mgr = AppWidgetManager.getInstance(this)
        val cn = ComponentName(this, VisualizerWidget::class.java)
        val buf = ShortArray(N); val re = DoubleArray(N); val im = DoubleArray(N)
        val lv = FloatArray(BARS)
        var last = 0L; var lastInfo = 0L
        var ids = mgr.getAppWidgetIds(cn)
        rec.startRecording()
        try {
            while (running) {
                val got = rec.read(buf, 0, N)
                if (got < N) continue
                for (k in 0 until N) { re[k] = buf[k] / 32768.0 * (0.5 - 0.5 * cos(2 * PI * k / (N - 1))); im[k] = 0.0 }
                fft(re, im)
                for (b in 0 until BARS) {
                    val lo = 1 + (400.0.pow(b / BARS.toDouble())).toInt()
                    val hi = max(lo + 1, 1 + (400.0.pow((b + 1) / BARS.toDouble())).toInt())
                    var m = 0.0
                    for (k in lo until hi) m = max(m, hypot(re[k], im[k]) / N * 4)
                    val v = ((20 * log10(m + 1e-6) + 70) / 60).toFloat().coerceIn(0f, 1f)
                    lv[b] = max(v, lv[b] * 0.85f)
                }
                val now = System.currentTimeMillis()
                if (now - last < 66) continue // ~15 кадров/с
                last = now
                if (now - lastInfo > 1000) { lastInfo = now; ids = mgr.getAppWidgetIds(cn); push(mgr, ids, null, track()) }
                push(mgr, ids, draw(lv), null)
            }
        } catch (_: Exception) { }
    }

    private fun push(mgr: AppWidgetManager, ids: IntArray, bmp: Bitmap?, title: String?) {
        if (ids.isEmpty()) return
        val rv = RemoteViews(packageName, R.layout.widget)
        bmp?.let { rv.setImageViewBitmap(R.id.img, it) }
        title?.let { rv.setTextViewText(R.id.title, it.ifEmpty { "Музыка не играет" }) }
        mgr.partiallyUpdateAppWidget(ids, rv)
    }

    private fun draw(lv: FloatArray): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, H.toFloat(), 0f, 0f, 0xFF00E5FF.toInt(), 0xFFFF4081.toInt(), Shader.TileMode.CLAMP)
        }
        val c = Canvas(bmp); val bw = W / BARS.toFloat()
        for (b in 0 until BARS) {
            val h = max(6f, lv[b] * H)
            c.drawRoundRect(b * bw + 4, H - h, (b + 1) * bw - 4, H.toFloat(), 8f, 8f, p)
        }
        return bmp
    }

    private fun track(): String = try {
        val sessions = getSystemService(MediaSessionManager::class.java)
            .getActiveSessions(ComponentName(this, NotifListener::class.java))
        val m = sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }?.metadata
        listOfNotNull(m?.getString(MediaMetadata.METADATA_KEY_ARTIST), m?.getString(MediaMetadata.METADATA_KEY_TITLE))
            .joinToString(" — ")
    } catch (e: SecurityException) { "Включите доступ к уведомлениям" }

    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size; var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { val t = re[i]; re[i] = re[j]; re[j] = t }
        }
        var len = 2
        while (len <= n) {
            val a = -2 * PI / len; val wr = cos(a); val wi = sin(a)
            var i = 0
            while (i < n) {
                var cr = 1.0; var ci = 0.0
                for (k in 0 until len / 2) {
                    val x = i + k; val y = x + len / 2
                    val tr = re[y] * cr - im[y] * ci; val ti = re[y] * ci + im[y] * cr
                    re[y] = re[x] - tr; im[y] = im[x] - ti; re[x] += tr; im[x] += ti
                    val t = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = t
                }
                i += len
            }
            len = len shl 1
        }
    }

    override fun onDestroy() {
        running = false
        try { record?.stop(); record?.release() } catch (_: Exception) { }
        projection?.stop()
        super.onDestroy()
    }
}
