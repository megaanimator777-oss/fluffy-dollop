package com.example.musicviz

import android.service.notification.NotificationListenerService

/** Пустой сервис: наличие доступа к уведомлениям позволяет читать MediaSession (название трека). */
class NotifListener : NotificationListenerService()
