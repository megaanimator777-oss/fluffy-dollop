package com.example.musicviz

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var img: ImageView
    private lateinit var st: TextView
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { Live.bmp?.let { img.setImageBitmap(it) }; st.text = Live.status; h.postDelayed(this, 80) }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val cfg = Cfg(this)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        fun label(t: String) = l.addView(TextView(this).apply { text = t; textSize = 13f; setPadding(0, 24, 0, 0) })
        fun btn(t: String, a: () -> Unit) = l.addView(Button(this).apply { text = t; setOnClickListener { a() } })

        img = ImageView(this).apply { setBackgroundColor(0xFF1A1A1A.toInt()) }
        l.addView(img, LinearLayout.LayoutParams(-1, 460))
        st = TextView(this).apply { textSize = 12f }
        l.addView(st)

        btn("1. Разрешить запись звука и уведомления") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("2. Доступ к уведомлениям (названия треков)") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        btn("3. Отключить оптимизацию батареи") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        btn("4. Запустить визуализацию") {
            startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 7)
        }
        btn("Остановить") { stopService(Intent(this, VisualizerService::class.java)) }

        label("Режим")
        l.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Столбики", "Зеркальные столбики", "Волна", "Круг"))
            setSelection(cfg.mode)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { cfg.mode = pos }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        })

        label("Чувствительность")
        l.addView(seek(100, cfg.sens) { cfg.sens = it })

        colorRow(l, "Цвет 1", { cfg.colorA }, { cfg.colorA = it })
        l.addView(CheckBox(this).apply {
            text = "Градиент (второй цвет)"; isChecked = cfg.grad
            setOnCheckedChangeListener { _, b -> cfg.grad = b }
        })
        colorRow(l, "Цвет 2", { cfg.colorB }, { cfg.colorB = it })

        label("Виджет: долгое нажатие на рабочем столе → Виджеты → Music Visualizer.")
        setContentView(ScrollView(this).apply { addView(l) })
    }

    private fun seek(max: Int, start: Int, on: (Int) -> Unit) = SeekBar(this).apply {
        this.max = max; progress = start
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { on(v) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun colorRow(l: LinearLayout, title: String, get: () -> Int, set: (Int) -> Unit) {
        val hsv = FloatArray(3); Color.colorToHSV(get(), hsv)
        val sw = View(this)
        fun apply() { val c = Color.HSVToColor(hsv); sw.setBackgroundColor(c); set(c) }
        l.addView(TextView(this).apply { text = title; setPadding(0, 24, 0, 8) })
        l.addView(sw, LinearLayout.LayoutParams(-1, 56))
        l.addView(seek(359, hsv[0].toInt()) { hsv[0] = it.toFloat(); apply() })
        l.addView(seek(100, (hsv[1] * 100).toInt()) { hsv[1] = it / 100f; apply() })
        l.addView(seek(100, (hsv[2] * 100).toInt()) { hsv[2] = it / 100f; apply() })
        apply()
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, code: Int, d: Intent?) {
        if (r == 7 && code == RESULT_OK && d != null)
            startForegroundService(Intent(this, VisualizerService::class.java).putExtra("code", code).putExtra("data", d))
    }
}
