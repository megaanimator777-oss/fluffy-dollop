package com.example.musicviz

import android.app.*
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.media.*
import android.media.audiofx.Visualizer
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.IBinder
import android.widget.RemoteViews
import kotlin.concurrent.thread
import kotlin.math.*

class VisualizerService : Service() {
    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    private var viz: Visualizer? = null
    private val cfg by lazy { Cfg(this) }
    private var title = ""
    @Volatile private var running = false

    companion object { const val N = 1024; const val BARS = 32; const val W = 480; const val H = 240 }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("viz", "Visualizer", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "viz").setContentTitle("Визуализатор работает")
            .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        @Suppress("DEPRECATION") val data = i?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            projection = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), data)
            projection!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, null)
            val cc = AudioPlaybackCaptureConfiguration.Builder(projection!!)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA).addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build()
            val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(44100).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
            record = AudioRecord.Builder().setAudioFormat(fmt).setBufferSizeInBytes(N * 8)
                .setAudioPlaybackCaptureConfig(cc).build()
        } catch (e: Exception) {
            Live.status = "Не удалось начать захват (дали разрешение на запись звука?): ${e.message}"
            stopSelf(); return START_NOT_STICKY
        }
        running = true
        thread { loop() }
        return START_NOT_STICKY
    }

    private fun loop() {
        val rec = record ?: return
        val mgr = AppWidgetManager.getInstance(this)
        val cn = ComponentName(this, VisualizerWidget::class.java)
        val am = getSystemService(AudioManager::class.java)
        val buf = ShortArray(N); val wb = ByteArray(N)
        val re = DoubleArray(N); val im = DoubleArray(N); val lv = FloatArray(BARS)
        var ids = mgr.getAppWidgetIds(cn)
        var last = 0L; var lastInfo = 0L; var lastSound = System.currentTimeMillis()
        rec.startRecording()
        while (running) {
            try {
                val v = viz
                if (v == null) {
                    if (rec.read(buf, 0, N) < N) { Thread.sleep(20); continue }
                    for (k in 0 until N) re[k] = buf[k] / 32768.0
                } else {
                    v.getWaveForm(wb); Thread.sleep(30)
                    for (k in 0 until N) re[k] = ((wb[k].toInt() and 0xFF) - 128) / 128.0
                }
                var peak = 0.0
                for (k in 0 until N) { peak = max(peak, abs(re[k])); re[k] *= 0.5 - 0.5 * cos(2 * PI * k / (N - 1)); im[k] = 0.0 }
                val now = System.currentTimeMillis()
                if (peak > 0.001) lastSound = now
                // Если перехват молчит, а музыка играет (приложение запретило захват) — берём системный Visualizer
                if (viz == null && now - lastSound > 3000 && am.isMusicActive) {
                    lastSound = now
                    viz = Visualizer(0).also { it.setEnabled(false); it.setCaptureSize(N); it.setEnabled(true) }
                }
                fft(re, im)
                val gain = 10.0.pow((cfg.sens - 50) / 50.0)
                for (b in 0 until BARS) {
                    val lo = 1 + 400.0.pow(b / BARS.toDouble()).toInt()
                    val hi = max(lo + 1, 1 + 400.0.pow((b + 1) / BARS.toDouble()).toInt())
                    var m = 0.0
                    for (k in lo until hi) m = max(m, hypot(re[k], im[k]) / N * 4)
                    val lvl = ((20 * log10(m * gain + 1e-6) + 70) / 60).toFloat().coerceIn(0f, 1f)
                    lv[b] = max(lvl, lv[b] * 0.85f)
                }
                if (now - last < 80) continue
                last = now
                if (now - lastInfo > 1000) {
                    lastInfo = now; ids = mgr.getAppWidgetIds(cn); title = track()
                    push(mgr, ids, null, title)
                    Live.status = "Источник: ${if (viz == null) "перехват звука приложений" else "системный Visualizer"}" +
                        " · уровень %.3f\nТрек: %s".format(peak, title.ifEmpty { "—" })
                }
                val bmp = draw(lv)
                Live.bmp = bmp
                push(mgr, ids, bmp, null)
            } catch (e: Exception) {
                Live.status = "Ошибка: ${e.javaClass.simpleName} ${e.message}"
                try { Thread.sleep(200) } catch (_: InterruptedException) { }
            }
        }
    }

    private fun push(mgr: AppWidgetManager, ids: IntArray, bmp: Bitmap?, title: String?) {
        if (ids.isEmpty()) return
        val rv = RemoteViews(packageName, R.layout.widget)
        bmp?.let { rv.setImageViewBitmap(R.id.img, it) }
        title?.let { rv.setTextViewText(R.id.title, it.ifEmpty { "Музыка не играет" }) }
        mgr.partiallyUpdateAppWidget(ids, rv)
    }

    private fun draw(lv: FloatArray): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val a = cfg.colorA; val b = if (cfg.grad) cfg.colorB else a
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, H.toFloat(), 0f, 0f, a, b, Shader.TileMode.CLAMP)
            strokeCap = Paint.Cap.ROUND
        }
        val bw = W / BARS.toFloat(); val hh = H.toFloat()
        when (cfg.mode) {
            0 -> for (i in 0 until BARS) {
                val h = max(6f, lv[i] * H)
                c.drawRoundRect(i * bw + 2, hh - h, (i + 1) * bw - 2, hh, 5f, 5f, p)
            }
            1 -> for (i in 0 until BARS) {
                val h = max(3f, lv[i] * H / 2)
                c.drawRoundRect(i * bw + 2, hh / 2 - h, (i + 1) * bw - 2, hh / 2 + h, 5f, 5f, p)
            }
            2 -> {
                val xs = FloatArray(BARS) { (it + .5f) * bw }
                val ys = FloatArray(BARS) { hh - max(4f, lv[it] * hh * .95f) }
                val path = Path().apply {
                    moveTo(xs[0], ys[0])
                    for (i in 1 until BARS) quadTo(xs[i - 1], ys[i - 1], (xs[i - 1] + xs[i]) / 2, (ys[i - 1] + ys[i]) / 2)
                    lineTo(xs[BARS - 1], ys[BARS - 1])
                }
                val fill = Path(path).apply { lineTo(xs[BARS - 1], hh); lineTo(xs[0], hh); close() }
                p.alpha = 90; c.drawPath(fill, p)
                p.alpha = 255; p.style = Paint.Style.STROKE; p.strokeWidth = 5f; c.drawPath(path, p)
            }
            else -> {
                val cx = W / 2f; val cy = hh / 2; val r0 = hh * .2f; val rl = hh * .28f
                p.style = Paint.Style.STROKE; p.strokeWidth = 6f
                val n = BARS * 2
                for (i in 0 until n) {
                    val k = if (i < BARS) i else n - 1 - i
                    val ang = i * 2 * PI / n - PI / 2
                    val r1 = r0 + max(3f, lv[k] * rl)
                    c.drawLine(cx + (r0 * cos(ang)).toFloat(), cy + (r0 * sin(ang)).toFloat(),
                        cx + (r1 * cos(ang)).toFloat(), cy + (r1 * sin(ang)).toFloat(), p)
                }
            }
        }
        return bmp
    }

    private fun track(): String = try {
        val ss = getSystemService(MediaSessionManager::class.java).getActiveSessions(ComponentName(this, NotifListener::class.java))
        val m = (ss.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING })?.metadata
        listOfNotNull(m?.getString(MediaMetadata.METADATA_KEY_ARTIST), m?.getString(MediaMetadata.METADATA_KEY_TITLE)).joinToString(" — ")
    } catch (e: SecurityException) { "Включите доступ к уведомлениям" }

    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size; var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { val t = re[i]; re[i] = re[j]; re[j] = t }
        }
        var len = 2
        while (len <= n) {
            val a = -2 * PI / len; val wr = cos(a); val wi = sin(a)
            var i = 0
            while (i < n) {
                var cr = 1.0; var ci = 0.0
                for (k in 0 until len / 2) {
                    val x = i + k; val y = x + len / 2
                    val tr = re[y] * cr - im[y] * ci; val ti = re[y] * ci + im[y] * cr
                    re[y] = re[x] - tr; im[y] = im[x] - ti; re[x] += tr; im[x] += ti
                    val t = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = t
                }
                i += len
            }
            len = len shl 1
        }
    }

    override fun onDestroy() {
        running = false
        Live.status = "Сервис не запущен"
        try { viz?.release() } catch (_: Exception) { }
        try { record?.stop(); record?.release() } catch (_: Exception) { }
        projection?.stop()
        super.onDestroy()
    }
}
